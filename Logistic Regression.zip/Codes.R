# Import libraries
library(dplyr) # data manipulation
library(ggplot2) # data viz
library(ROCR) # for ROC
library(caret)
library(GGally)
library(lubridate)


setwd("C:\\Users\\Admin\\OneDrive\\Desktop\\Kaggle-competition")
loan <- read.csv("loan_details_train.csv", na = "")
test <- read.csv("loan_details_test.csv")
sample <- read.csv("loan_details_sample.csv")


glimpse(loan1)
loan <- select(loan, -last_col())
colSums(is.na(loan))
loan1 <- na.omit(loan)
colSums(is.na(loan1))


loan1$Date.of.Birth <- ymd(loan1$Date.of.Birth)
loan1$birthYear <- year(loan1$Date.of.Birth)
loan1$DisbursalDate <- dmy(loan1$DisbursalDate)
loan1$disbursalYear <- year(loan1$DisbursalDate)
loan1$disbursalMonth <- month(loan1$DisbursalDate)
loan1 <- loan1 %>% select(-birthyear)

mod1 <- glm(default ~ disbursed_amount + asset_cost + ltv + branch_id + 
            + PERFORM_CNS.SCORE + as.factor(DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS)
            + as.factor(region) + as.factor(Employment.Type) + as.numeric(DisbursalDate)
            + as.factor(NO.OF_INQUIRIES) + CREDIT.HISTORY.LENGTH, 
            data=loan, family= "binomial")

summary(mod1)

loan2 <- read.csv("New_loan.csv")
colSums(is.na(loan2))
str(loan2)
table(loan2$Credit.Length)

loan2$Employment.Type <- as.character(loan2$Employment.Type)
loan2$region <- as.character(loan2$region)
loan2$AGE.GROUP <- as.character(loan2$AGE.GROUP)
loan2$DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS <- as.numeric(loan2$DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS)
loan2$Credit.Length <- as.character(loan2$Credit.Length)

glimpse(loan2)

loan2$DisbursalDate <- dmy(loan2$DisbursalDate)
loan2$disbursalMonth <- month(loan2$DisbursalDate)

loan1$default <- as.numeric(loan2$default)
loan2

mod2 <- glm(default ~ disbursed_amount + asset_cost + ltv + as.factor(branch_id) + 
              + PERFORM_CNS.SCORE + as.factor(DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS)
            + as.factor(region) + as.factor(Employment.Type) + as.factor(NO.OF_INQUIRIES) + as.factor(AGE.GROUP) + as.factor(Credit.Length) +
              as.factor(disbursalMonth) + AGE, 
            data=loan2, family="binomial")
summary(mod2)

mod3 <- glm(default ~ disbursed_amount + asset_cost + ltv + branch_id + 
              + PERFORM_CNS.SCORE + DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS
            + as.factor(region) + as.factor(Employment.Type) + NO.OF_INQUIRIES
            + as.factor(AGE.GROUP) + as.factor(Credit.Length) +
              as.factor(disbursalMonth) + AGE, 
            data=loan2, family="binomial")
summary(mod3)

mod4 <- glm(default ~ disbursed_amount + asset_cost + ltv + branch_id + 
              + PERFORM_CNS.SCORE + DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS
            + as.factor(region) + as.factor(Employment.Type) + NO.OF_INQUIRIES
            + Years + as.factor(disbursalMonth) + AGE, 
            data=loan2, family="binomial")
summary(mod4)

mod5 <- glm(default ~ disbursed_amount + asset_cost + ltv + branch_id + 
              + PERFORM_CNS.SCORE + DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS
            + as.factor(region) + as.factor(Employment.Type) + NO.OF_INQUIRIES
            + Years + as.factor(disbursalMonth) + AGE + Aadhar_flag, 
            data=loan2, family="binomial")
summary(mod5)

test$DisbursalDate <- dmy(test$DisbursalDate)
test$disbursalMonth <- month(test$DisbursalDate)

predicted<-predict(mod5,test, type = "response")
predicted

test$DEFAULT<-predicted
head(test)
final<-test[,c("ID","DEFAULT")]
head(final)

submission <- read.csv("loan_details_sample.csv")
write.csv(final, "Submit File", row.names = FALSE)
